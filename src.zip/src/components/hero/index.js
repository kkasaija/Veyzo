export { default } from './Hero';
